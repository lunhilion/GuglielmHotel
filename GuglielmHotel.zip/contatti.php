
<?php
    require_once('php/functions.php');
    BuildPage("Contattaci","contents/contatti.html");
?>