<?php
    require_once('php/functions.php');
    BuildPage("Attorno a noi","contents/dintorni.html");
?>