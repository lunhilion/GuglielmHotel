<?php
    require_once('php/functions.php');
    BuildPage("404","contents/404.html");
?>