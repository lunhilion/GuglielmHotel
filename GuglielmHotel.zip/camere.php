<?php
    require_once('php/functions.php');
    BuildPage("Le nostre camere","contents/camere.html");
?>