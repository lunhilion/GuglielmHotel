<?php
    require_once('php/functions.php');
    BuildPage("Come raggiungerci","contents/come_raggiungerci.html");
?>