# Guglielm Hotel


## Cose da fare
### Generali:
- [ ] aggiungere tab index (?)
- [ ] supporto per screenreader
- [ ] aggiungere attributo lang=EN dove serve
- [ ] rendere accessibile tabella cpanel
- [ ] rendere accessibili caratteri speciali
- [ ] aggiungere breadcrumb
- [ ] controllare input javascript
- [ ] hamburger (?)
- [ ] pagina 404 ??


### Silvia:
- [ ] sistemare css print
- [ ] relazione


### Erny:
- [ ] sistemare bounds disponibilita' php
- [ ] validare pagine

