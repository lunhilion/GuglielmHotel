<?php
    require_once('php/functions.php');
    BuildPage("I nostri servizi","contents/servizi.html");
?>