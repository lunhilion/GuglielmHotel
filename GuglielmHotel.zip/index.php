<?php
    require_once('php/functions.php');
    BuildPage("Home","contents/home.html");
?>