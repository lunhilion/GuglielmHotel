# GuglielmHotel


COSE DA FARE:
. finire di sistemare le pagine
. caricare font locale
. aggiungere box booking
. aggiungere bottone booking
. scrivere css mobile+stampa
. aggiungere favicon

